const menuToggle = document.querySelector('.menu-toggle');
const mainNav = document.querySelector('#main-nav');
const newsletterForm = document.querySelector('#newsletter-form');
const formMessage = document.querySelector('#form-message');

menuToggle?.addEventListener('click', () => {
	const isOpen = mainNav.classList.toggle('open');
	menuToggle.setAttribute('aria-expanded', String(isOpen));
});

document.querySelectorAll('.main-nav a').forEach((link) => {
	link.addEventListener('click', () => {
		mainNav.classList.remove('open');
		menuToggle?.setAttribute('aria-expanded', 'false');
	});
});

newsletterForm?.addEventListener('submit', (event) => {
	event.preventDefault();
	formMessage.textContent = 'Inscrição recebida. Nos vemos na próxima edição.';
	newsletterForm.reset();
});

const revealObserver = new IntersectionObserver((entries) => {
	entries.forEach((entry) => {
		if (entry.isIntersecting) {
			entry.target.classList.add('visible');
			revealObserver.unobserve(entry.target);
		}
	});
}, { threshold: 0.12 });

document.querySelectorAll('.reveal').forEach((element) => revealObserver.observe(element));
